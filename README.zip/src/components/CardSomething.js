 import React from "react";
import { Image, Text, View ,Platform, TouchableOpacity } from "react-native";

const CardSomething = (prop) => {
  const { img, number, deliveredOrPending, color,route } = prop;
  return (
    <View className=" w-[42%] shadow-gl   bg-[#FFFFFE]  ml-5  rounded-xl   "   style={{  ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
      },
      android: {
        elevation: 5,
      },
    }),
    default: {
      // For other platforms, you can provide a fallback shadow
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
    }}}>
      <TouchableOpacity className="w-full h-full" 
      onPress={route} >

      <Image
        className=" w-[64%] h-[57%] ml-[13%] mt-5"
        source={img}
        />
      
      <Text className="text-lg  mt-3 ml-[25%]">{deliveredOrPending}</Text>
        </TouchableOpacity>
    </View>
  );
};

export default CardSomething;
