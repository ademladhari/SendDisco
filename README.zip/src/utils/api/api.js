import axios from "axios";
import { URL_BASE } from "../../services/constants";

export const getApi = axios.create({
  baseURL: "https://65df98ccff5e305f32a2a067.mockapi.io/api/test/",
  headers: { "Content-Type": "application/json" },
  withCredentials: true,
});
export const getApiAuth = axios.create({
  baseURL: URL_BASE ,
  headers: { "Content-Type": "application/json" },
  withCredentials: true,
});
