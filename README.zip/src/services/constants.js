export const URL_BASE="http://192.168.0.14:3000/api/auth/"
export const LOGIN=`${URL_BASE}login/`